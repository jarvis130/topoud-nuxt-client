import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _c8986a18 = () => import('../app/nuxt/pages/test.vue' /* webpackChunkName: "pages/test" */).then(m => m.default || m)
const _7ed4dbf0 = () => import('../app/nuxt/pages/client/index.vue' /* webpackChunkName: "pages/client/index" */).then(m => m.default || m)
const _22ce21ac = () => import('../app/nuxt/pages/client/my/homepage/create.vue' /* webpackChunkName: "pages/client/my/homepage/create" */).then(m => m.default || m)
const _c72491a2 = () => import('../app/nuxt/pages/client/my/homepage/create/index.vue' /* webpackChunkName: "pages/client/my/homepage/create/index" */).then(m => m.default || m)
const _7a5a1b4c = () => import('../app/nuxt/pages/client/my/homepage/create/template-select.vue' /* webpackChunkName: "pages/client/my/homepage/create/template-select" */).then(m => m.default || m)
const _9f19b0b4 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-edit" */).then(m => m.default || m)
const _52477396 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-add.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-add" */).then(m => m.default || m)
const _9322f422 = () => import('../app/nuxt/pages/client/my/homepage/create/industries.vue' /* webpackChunkName: "pages/client/my/homepage/create/industries" */).then(m => m.default || m)
const _c02e881e = () => import('../app/nuxt/pages/client/my/homepage/create/panel-config.js' /* webpackChunkName: "pages/client/my/homepage/create/panel-config" */).then(m => m.default || m)
const _bda9ff8c = () => import('../app/nuxt/pages/client/my/homepage/create/panel-list.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-list" */).then(m => m.default || m)
const _3fa3792a = () => import('../app/nuxt/pages/client/home/_storeId.vue' /* webpackChunkName: "pages/client/home/_storeId" */).then(m => m.default || m)
const _aeea734a = () => import('../app/nuxt/pages/home/_storeId.vue' /* webpackChunkName: "pages/home/_storeId" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _c8986a18,
			name: "test"
		},
		{
			path: "/client",
			component: _7ed4dbf0,
			name: "client"
		},
		{
			path: "/client/my/homepage/create",
			component: _22ce21ac,
			children: [
				{
					path: "",
					component: _c72491a2,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _7a5a1b4c,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _9f19b0b4,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _52477396,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "industries",
					component: _9322f422,
					name: "client-my-homepage-create-industries"
				},
				{
					path: "panel-config",
					component: _c02e881e,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _bda9ff8c,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _3fa3792a,
			name: "client-home-storeId"
		},
		{
			path: "/home/:storeId?",
			component: _aeea734a,
			name: "home-storeId"
		}
    ],
    
    
    fallback: false
  })
}
