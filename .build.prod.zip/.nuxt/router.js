import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _17223612 = () => import('../app/nuxt/pages/test.vue' /* webpackChunkName: "pages/test" */).then(m => m.default || m)
const _2f9f788e = () => import('../app/nuxt/pages/payment-code.vue' /* webpackChunkName: "pages/payment-code" */).then(m => m.default || m)
const _c6b97a1a = () => import('../app/nuxt/pages/client/index.vue' /* webpackChunkName: "pages/client/index" */).then(m => m.default || m)
const _e8ad6c3a = () => import('../app/nuxt/pages/payment-choose.vue' /* webpackChunkName: "pages/payment-choose" */).then(m => m.default || m)
const _b1b50a84 = () => import('../app/nuxt/pages/paymentCode.vue' /* webpackChunkName: "pages/paymentCode" */).then(m => m.default || m)
const _45787789 = () => import('../app/nuxt/pages/client/my/homepage/create.vue' /* webpackChunkName: "pages/client/my/homepage/create" */).then(m => m.default || m)
const _97f51968 = () => import('../app/nuxt/pages/client/my/homepage/create/index.vue' /* webpackChunkName: "pages/client/my/homepage/create/index" */).then(m => m.default || m)
const _125f1729 = () => import('../app/nuxt/pages/client/my/homepage/create/template-select.vue' /* webpackChunkName: "pages/client/my/homepage/create/template-select" */).then(m => m.default || m)
const _806514ae = () => import('../app/nuxt/pages/client/my/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-edit" */).then(m => m.default || m)
const _b462a85c = () => import('../app/nuxt/pages/client/my/homepage/create/panel-add.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-add" */).then(m => m.default || m)
const _746e581c = () => import('../app/nuxt/pages/client/my/homepage/create/industries.vue' /* webpackChunkName: "pages/client/my/homepage/create/industries" */).then(m => m.default || m)
const _7bd82e4e = () => import('../app/nuxt/pages/client/my/homepage/create/panel-config.js' /* webpackChunkName: "pages/client/my/homepage/create/panel-config" */).then(m => m.default || m)
const _9ef56386 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-list.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-list" */).then(m => m.default || m)
const _d51a1124 = () => import('../app/nuxt/pages/client/home/_storeId.vue' /* webpackChunkName: "pages/client/home/_storeId" */).then(m => m.default || m)
const _44893fb8 = () => import('../app/nuxt/pages/home/_storeId.vue' /* webpackChunkName: "pages/home/_storeId" */).then(m => m.default || m)
const _25001941 = () => import('../app/nuxt/pages/c-_articleId.vue' /* webpackChunkName: "pages/c-_articleId" */).then(m => m.default || m)
const _d082d1f2 = () => import('../app/nuxt/pages/h-_storeId.vue' /* webpackChunkName: "pages/h-_storeId" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _17223612,
			name: "test"
		},
		{
			path: "/payment-code",
			component: _2f9f788e,
			name: "payment-code"
		},
		{
			path: "/client",
			component: _c6b97a1a,
			name: "client"
		},
		{
			path: "/payment-choose",
			component: _e8ad6c3a,
			name: "payment-choose"
		},
		{
			path: "/paymentCode",
			component: _b1b50a84,
			name: "paymentCode"
		},
		{
			path: "/client/my/homepage/create",
			component: _45787789,
			children: [
				{
					path: "",
					component: _97f51968,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _125f1729,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _806514ae,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _b462a85c,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "industries",
					component: _746e581c,
					name: "client-my-homepage-create-industries"
				},
				{
					path: "panel-config",
					component: _7bd82e4e,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _9ef56386,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _d51a1124,
			name: "client-home-storeId"
		},
		{
			path: "/home/:storeId?",
			component: _44893fb8,
			name: "home-storeId"
		},
		{
			path: "/c-:articleId",
			component: _25001941,
			name: "c-articleId"
		},
		{
			path: "/h-:storeId",
			component: _d082d1f2,
			name: "h-storeId"
		}
    ],
    
    
    fallback: false
  })
}
