import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _5cabf71c = () => import('../app/nuxt/pages/test.vue' /* webpackChunkName: "pages/test" */).then(m => m.default || m)
const _94db3fd0 = () => import('../app/nuxt/pages/client/index.vue' /* webpackChunkName: "pages/client/index" */).then(m => m.default || m)
const _2dce9e84 = () => import('../app/nuxt/pages/client/my/homepage/create.vue' /* webpackChunkName: "pages/client/my/homepage/create" */).then(m => m.default || m)
const _e3399bf2 = () => import('../app/nuxt/pages/client/my/homepage/create/index.vue' /* webpackChunkName: "pages/client/my/homepage/create/index" */).then(m => m.default || m)
const _47942fb8 = () => import('../app/nuxt/pages/client/my/homepage/create/template-select.vue' /* webpackChunkName: "pages/client/my/homepage/create/template-select" */).then(m => m.default || m)
const _4f70b3ce = () => import('../app/nuxt/pages/client/my/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-edit" */).then(m => m.default || m)
const _ed2ed5e6 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-add.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-add" */).then(m => m.default || m)
const _556c1217 = () => import('../app/nuxt/pages/client/my/homepage/create/industries.vue' /* webpackChunkName: "pages/client/my/homepage/create/industries" */).then(m => m.default || m)
const _3ec6966e = () => import('../app/nuxt/pages/client/my/homepage/create/panel-config.js' /* webpackChunkName: "pages/client/my/homepage/create/panel-config" */).then(m => m.default || m)
const _40288c62 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-list.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-list" */).then(m => m.default || m)
const _7dd91f93 = () => import('../app/nuxt/pages/client/home/_storeId.vue' /* webpackChunkName: "pages/client/home/_storeId" */).then(m => m.default || m)
const _497dc733 = () => import('../app/nuxt/pages/home/_storeId.vue' /* webpackChunkName: "pages/home/_storeId" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _5cabf71c,
			name: "test"
		},
		{
			path: "/client",
			component: _94db3fd0,
			name: "client"
		},
		{
			path: "/client/my/homepage/create",
			component: _2dce9e84,
			children: [
				{
					path: "",
					component: _e3399bf2,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _47942fb8,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _4f70b3ce,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _ed2ed5e6,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "industries",
					component: _556c1217,
					name: "client-my-homepage-create-industries"
				},
				{
					path: "panel-config",
					component: _3ec6966e,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _40288c62,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _7dd91f93,
			name: "client-home-storeId"
		},
		{
			path: "/home/:storeId?",
			component: _497dc733,
			name: "home-storeId"
		}
    ],
    
    
    fallback: false
  })
}
