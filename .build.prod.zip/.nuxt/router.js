import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _52a96aae = () => import('../app/nuxt/pages/test.vue' /* webpackChunkName: "pages/test" */).then(m => m.default || m)
const _3466512a = () => import('../app/nuxt/pages/payment-code.vue' /* webpackChunkName: "pages/payment-code" */).then(m => m.default || m)
const _cb8052b6 = () => import('../app/nuxt/pages/client/index.vue' /* webpackChunkName: "pages/client/index" */).then(m => m.default || m)
const _d7208dd6 = () => import('../app/nuxt/pages/payment-choose.vue' /* webpackChunkName: "pages/payment-choose" */).then(m => m.default || m)
const _1aaea8cc = () => import('../app/nuxt/pages/paymentCode.vue' /* webpackChunkName: "pages/paymentCode" */).then(m => m.default || m)
const _a74e15d2 = () => import('../app/nuxt/pages/client/my/homepage/create.vue' /* webpackChunkName: "pages/client/my/homepage/create" */).then(m => m.default || m)
const _35890e5a = () => import('../app/nuxt/pages/client/my/homepage/create/index.vue' /* webpackChunkName: "pages/client/my/homepage/create/index" */).then(m => m.default || m)
const _68deb8b7 = () => import('../app/nuxt/pages/client/my/homepage/create/template-select.vue' /* webpackChunkName: "pages/client/my/homepage/create/template-select" */).then(m => m.default || m)
const _4f36935b = () => import('../app/nuxt/pages/client/my/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-edit" */).then(m => m.default || m)
const _36d20fe0 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-add.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-add" */).then(m => m.default || m)
const _5531f1a4 = () => import('../app/nuxt/pages/client/my/homepage/create/industries.vue' /* webpackChunkName: "pages/client/my/homepage/create/industries" */).then(m => m.default || m)
const _4cda7248 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-config.js' /* webpackChunkName: "pages/client/my/homepage/create/panel-config" */).then(m => m.default || m)
const _3fee6bef = () => import('../app/nuxt/pages/client/my/homepage/create/panel-list.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-list" */).then(m => m.default || m)
const _cb3c8dc0 = () => import('../app/nuxt/pages/client/home/_storeId.vue' /* webpackChunkName: "pages/client/home/_storeId" */).then(m => m.default || m)
const _0b01bb74 = () => import('../app/nuxt/pages/home/_storeId.vue' /* webpackChunkName: "pages/home/_storeId" */).then(m => m.default || m)
const _229cacf3 = () => import('../app/nuxt/pages/c-_articleId.vue' /* webpackChunkName: "pages/c-_articleId" */).then(m => m.default || m)
const _7a706f39 = () => import('../app/nuxt/pages/h-_storeId.vue' /* webpackChunkName: "pages/h-_storeId" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _52a96aae,
			name: "test"
		},
		{
			path: "/payment-code",
			component: _3466512a,
			name: "payment-code"
		},
		{
			path: "/client",
			component: _cb8052b6,
			name: "client"
		},
		{
			path: "/payment-choose",
			component: _d7208dd6,
			name: "payment-choose"
		},
		{
			path: "/paymentCode",
			component: _1aaea8cc,
			name: "paymentCode"
		},
		{
			path: "/client/my/homepage/create",
			component: _a74e15d2,
			children: [
				{
					path: "",
					component: _35890e5a,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _68deb8b7,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _4f36935b,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _36d20fe0,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "industries",
					component: _5531f1a4,
					name: "client-my-homepage-create-industries"
				},
				{
					path: "panel-config",
					component: _4cda7248,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _3fee6bef,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _cb3c8dc0,
			name: "client-home-storeId"
		},
		{
			path: "/home/:storeId?",
			component: _0b01bb74,
			name: "home-storeId"
		},
		{
			path: "/c-:articleId",
			component: _229cacf3,
			name: "c-articleId"
		},
		{
			path: "/h-:storeId",
			component: _7a706f39,
			name: "h-storeId"
		}
    ],
    
    
    fallback: false
  })
}
