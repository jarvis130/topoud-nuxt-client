import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _d5c79a46 = () => import('../app/nuxt/pages/test.vue' /* webpackChunkName: "pages/test" */).then(m => m.default || m)
const _0b2f4ad9 = () => import('../app/nuxt/pages/client/index.vue' /* webpackChunkName: "pages/client/index" */).then(m => m.default || m)
const _4f9a153a = () => import('../app/nuxt/pages/client/my/homepage/create.vue' /* webpackChunkName: "pages/client/my/homepage/create" */).then(m => m.default || m)
const _4a3ca5a6 = () => import('../app/nuxt/pages/client/my/homepage/create/index.vue' /* webpackChunkName: "pages/client/my/homepage/create/index" */).then(m => m.default || m)
const _d9b2bdfa = () => import('../app/nuxt/pages/client/my/homepage/create/template-select.vue' /* webpackChunkName: "pages/client/my/homepage/create/template-select" */).then(m => m.default || m)
const _5fd9ab8f = () => import('../app/nuxt/pages/client/my/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-edit" */).then(m => m.default || m)
const _0e11212c = () => import('../app/nuxt/pages/client/my/homepage/create/panel-add.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-add" */).then(m => m.default || m)
const _65d509d8 = () => import('../app/nuxt/pages/client/my/homepage/create/industries.vue' /* webpackChunkName: "pages/client/my/homepage/create/industries" */).then(m => m.default || m)
const _455a95b0 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-config.js' /* webpackChunkName: "pages/client/my/homepage/create/panel-config" */).then(m => m.default || m)
const _50918423 = () => import('../app/nuxt/pages/client/my/homepage/create/panel-list.vue' /* webpackChunkName: "pages/client/my/homepage/create/panel-list" */).then(m => m.default || m)
const _66f88d58 = () => import('../app/nuxt/pages/client/home/_storeId.vue' /* webpackChunkName: "pages/client/home/_storeId" */).then(m => m.default || m)
const _b10396dc = () => import('../app/nuxt/pages/home/_storeId.vue' /* webpackChunkName: "pages/home/_storeId" */).then(m => m.default || m)
const _0957606d = () => import('../app/nuxt/pages/h-_storeId.vue' /* webpackChunkName: "pages/h-_storeId" */).then(m => m.default || m)
const _d8e7bdb2 = () => import('../app/nuxt/pages/c-_articleId.vue' /* webpackChunkName: "pages/c-_articleId" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _d5c79a46,
			name: "test"
		},
		{
			path: "/client",
			component: _0b2f4ad9,
			name: "client"
		},
		{
			path: "/client/my/homepage/create",
			component: _4f9a153a,
			children: [
				{
					path: "",
					component: _4a3ca5a6,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _d9b2bdfa,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _5fd9ab8f,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _0e11212c,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "industries",
					component: _65d509d8,
					name: "client-my-homepage-create-industries"
				},
				{
					path: "panel-config",
					component: _455a95b0,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _50918423,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _66f88d58,
			name: "client-home-storeId"
		},
		{
			path: "/home/:storeId?",
			component: _b10396dc,
			name: "home-storeId"
		},
		{
			path: "/h-:storeId",
			component: _0957606d,
			name: "h-storeId"
		},
		{
			path: "/c-:articleId",
			component: _d8e7bdb2,
			name: "c-articleId"
		}
    ],
    
    
    fallback: false
  })
}
