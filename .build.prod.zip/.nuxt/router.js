import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _1b83f101 = () => import('../app/nuxt/pages/client/index.vue' /* webpackChunkName: "pages/client/index" */).then(m => m.default || m)
const _26a9942c = () => import('../app/nuxt/pages/client/homepage/create.vue' /* webpackChunkName: "pages/client/homepage/create" */).then(m => m.default || m)
const _098949af = () => import('../app/nuxt/pages/client/homepage/create/index.vue' /* webpackChunkName: "pages/client/homepage/create/index" */).then(m => m.default || m)
const _62008dcc = () => import('../app/nuxt/pages/client/homepage/create/template-select.vue' /* webpackChunkName: "pages/client/homepage/create/template-select" */).then(m => m.default || m)
const _3a2f2526 = () => import('../app/nuxt/pages/client/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/client/homepage/create/panel-edit" */).then(m => m.default || m)
const _4eea98b5 = () => import('../app/nuxt/pages/client/homepage/create/panel-add.vue' /* webpackChunkName: "pages/client/homepage/create/panel-add" */).then(m => m.default || m)
const _4dac6e71 = () => import('../app/nuxt/pages/client/homepage/create/panel-config.js' /* webpackChunkName: "pages/client/homepage/create/panel-config" */).then(m => m.default || m)
const _2ae6fdba = () => import('../app/nuxt/pages/client/homepage/create/panel-list.vue' /* webpackChunkName: "pages/client/homepage/create/panel-list" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/client",
			component: _1b83f101,
			name: "client"
		},
		{
			path: "/client/homepage/create",
			component: _26a9942c,
			children: [
				{
					path: "",
					component: _098949af,
					name: "client-homepage-create"
				},
				{
					path: "template-select",
					component: _62008dcc,
					name: "client-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _3a2f2526,
					name: "client-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _4eea98b5,
					name: "client-homepage-create-panel-add"
				},
				{
					path: "panel-config",
					component: _4dac6e71,
					name: "client-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _2ae6fdba,
					name: "client-homepage-create-panel-list"
				}
			]
		}
    ],
    
    
    fallback: false
  })
}
