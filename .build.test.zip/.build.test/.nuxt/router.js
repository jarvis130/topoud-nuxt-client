import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _2b130554 = () => import('..\\app\\nuxt\\pages\\test.vue' /* webpackChunkName: "pages_test" */).then(m => m.default || m)
const _f9fdc356 = () => import('..\\app\\nuxt\\pages\\client\\index.vue' /* webpackChunkName: "pages_client_index" */).then(m => m.default || m)
const _e793463a = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create.vue' /* webpackChunkName: "pages_client_my_homepage_create" */).then(m => m.default || m)
const _7627423f = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\index.vue' /* webpackChunkName: "pages_client_my_homepage_create_index" */).then(m => m.default || m)
const _87a5db48 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\template-select.vue' /* webpackChunkName: "pages_client_my_homepage_create_template-select" */).then(m => m.default || m)
const _4f460696 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-edit.vue' /* webpackChunkName: "pages_client_my_homepage_create_panel-edit" */).then(m => m.default || m)
const _588c6d76 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-add.vue' /* webpackChunkName: "pages_client_my_homepage_create_panel-add" */).then(m => m.default || m)
const _491c89fe = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-config.js' /* webpackChunkName: "pages_client_my_homepage_create_panel-config" */).then(m => m.default || m)
const _3ffddf2a = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-list.vue' /* webpackChunkName: "pages_client_my_homepage_create_panel-list" */).then(m => m.default || m)
const _09c49b49 = () => import('..\\app\\nuxt\\pages\\client\\home\\_storeId.vue' /* webpackChunkName: "pages_client_home__storeId" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _2b130554,
			name: "test"
		},
		{
			path: "/client",
			component: _f9fdc356,
			name: "client"
		},
		{
			path: "/client/my/homepage/create",
			component: _e793463a,
			children: [
				{
					path: "",
					component: _7627423f,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _87a5db48,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _4f460696,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _588c6d76,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "panel-config",
					component: _491c89fe,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _3ffddf2a,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _09c49b49,
			name: "client-home-storeId"
		}
    ],
    
    
    fallback: false
  })
}
