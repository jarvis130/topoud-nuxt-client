import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _78910ad6 = () => import('../app/nuxt/pages/api/client/index.vue' /* webpackChunkName: "pages/api/client/index" */).then(m => m.default || m)
const _e197b07e = () => import('../app/nuxt/pages/api/client/homepage/create.vue' /* webpackChunkName: "pages/api/client/homepage/create" */).then(m => m.default || m)
const _609a1984 = () => import('../app/nuxt/pages/api/client/homepage/create/index.vue' /* webpackChunkName: "pages/api/client/homepage/create/index" */).then(m => m.default || m)
const _1839513e = () => import('../app/nuxt/pages/api/client/homepage/create/template-select.vue' /* webpackChunkName: "pages/api/client/homepage/create/template-select" */).then(m => m.default || m)
const _73bff271 = () => import('../app/nuxt/pages/api/client/homepage/create/panel-edit.vue' /* webpackChunkName: "pages/api/client/homepage/create/panel-edit" */).then(m => m.default || m)
const _0eb5760a = () => import('../app/nuxt/pages/api/client/homepage/create/panel-add.vue' /* webpackChunkName: "pages/api/client/homepage/create/panel-add" */).then(m => m.default || m)
const _46354a86 = () => import('../app/nuxt/pages/api/client/homepage/create/panel-config.js' /* webpackChunkName: "pages/api/client/homepage/create/panel-config" */).then(m => m.default || m)
const _6477cb05 = () => import('../app/nuxt/pages/api/client/homepage/create/panel-list.vue' /* webpackChunkName: "pages/api/client/homepage/create/panel-list" */).then(m => m.default || m)



const scrollBehavior = function (to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/api/client",
			component: _78910ad6,
			name: "api-client"
		},
		{
			path: "/api/client/homepage/create",
			component: _e197b07e,
			children: [
				{
					path: "",
					component: _609a1984,
					name: "api-client-homepage-create"
				},
				{
					path: "template-select",
					component: _1839513e,
					name: "api-client-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _73bff271,
					name: "api-client-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _0eb5760a,
					name: "api-client-homepage-create-panel-add"
				},
				{
					path: "panel-config",
					component: _46354a86,
					name: "api-client-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _6477cb05,
					name: "api-client-homepage-create-panel-list"
				}
			]
		}
    ],
    
    
    fallback: false
  })
}
