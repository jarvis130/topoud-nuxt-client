import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _35e1c461 = () => import('..\\app\\nuxt\\pages\\test.vue' /* webpackChunkName: "pages_test" */).then(m => m.default || m)
const _ceabcdba = () => import('..\\app\\nuxt\\pages\\payment-code.vue' /* webpackChunkName: "pages_payment-code" */).then(m => m.default || m)
const _19d80430 = () => import('..\\app\\nuxt\\pages\\client\\index.vue' /* webpackChunkName: "pages_client_index" */).then(m => m.default || m)
const _05036ccd = () => import('..\\app\\nuxt\\pages\\payment-choose.vue' /* webpackChunkName: "pages_payment-choose" */).then(m => m.default || m)
const _6ac65014 = () => import('..\\app\\nuxt\\pages\\paymentCode.vue' /* webpackChunkName: "pages_paymentCode" */).then(m => m.default || m)
const _4cec04f0 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create.vue' /* webpackChunkName: "pages_client_my_homepage_create" */).then(m => m.default || m)
const _7bb3e192 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\index.vue' /* webpackChunkName: "pages_client_my_homepage_create_index" */).then(m => m.default || m)
const _d8363422 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\template-select.vue' /* webpackChunkName: "pages_client_my_homepage_create_template-select" */).then(m => m.default || m)
const _7d31f9ba = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-edit.vue' /* webpackChunkName: "pages_client_my_homepage_create_panel-edit" */).then(m => m.default || m)
const _0f1ef1d0 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-add.vue' /* webpackChunkName: "pages_client_my_homepage_create_panel-add" */).then(m => m.default || m)
const _713b3d28 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\industries.vue' /* webpackChunkName: "pages_client_my_homepage_create_industries" */).then(m => m.default || m)
const _a51f5fd8 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-config.js' /* webpackChunkName: "pages_client_my_homepage_create_panel-config" */).then(m => m.default || m)
const _9bc24892 = () => import('..\\app\\nuxt\\pages\\client\\my\\homepage\\create\\panel-list.vue' /* webpackChunkName: "pages_client_my_homepage_create_panel-list" */).then(m => m.default || m)
const _64aeddd4 = () => import('..\\app\\nuxt\\pages\\client\\home\\_storeId.vue' /* webpackChunkName: "pages_client_home__storeId" */).then(m => m.default || m)
const _6cabac4b = () => import('..\\app\\nuxt\\pages\\home\\_storeId.vue' /* webpackChunkName: "pages_home__storeId" */).then(m => m.default || m)
const _550c22aa = () => import('..\\app\\nuxt\\pages\\c-_articleId.vue' /* webpackChunkName: "pages_c-_articleId" */).then(m => m.default || m)
const _1eba821e = () => import('..\\app\\nuxt\\pages\\h-_storeId.vue' /* webpackChunkName: "pages_h-_storeId" */).then(m => m.default || m)



const scrollBehavior = function(to, from, savedPosition) {
            if (savedPosition) {
                return savedPosition
            }
            return { x: 0, y: 0 }
        }


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/test",
			component: _35e1c461,
			name: "test"
		},
		{
			path: "/payment-code",
			component: _ceabcdba,
			name: "payment-code"
		},
		{
			path: "/client",
			component: _19d80430,
			name: "client"
		},
		{
			path: "/payment-choose",
			component: _05036ccd,
			name: "payment-choose"
		},
		{
			path: "/paymentCode",
			component: _6ac65014,
			name: "paymentCode"
		},
		{
			path: "/client/my/homepage/create",
			component: _4cec04f0,
			children: [
				{
					path: "",
					component: _7bb3e192,
					name: "client-my-homepage-create"
				},
				{
					path: "template-select",
					component: _d8363422,
					name: "client-my-homepage-create-template-select"
				},
				{
					path: "panel-edit",
					component: _7d31f9ba,
					name: "client-my-homepage-create-panel-edit"
				},
				{
					path: "panel-add",
					component: _0f1ef1d0,
					name: "client-my-homepage-create-panel-add"
				},
				{
					path: "industries",
					component: _713b3d28,
					name: "client-my-homepage-create-industries"
				},
				{
					path: "panel-config",
					component: _a51f5fd8,
					name: "client-my-homepage-create-panel-config"
				},
				{
					path: "panel-list",
					component: _9bc24892,
					name: "client-my-homepage-create-panel-list"
				}
			]
		},
		{
			path: "/client/home/:storeId?",
			component: _64aeddd4,
			name: "client-home-storeId"
		},
		{
			path: "/home/:storeId?",
			component: _6cabac4b,
			name: "home-storeId"
		},
		{
			path: "/c-:articleId",
			component: _550c22aa,
			name: "c-articleId"
		},
		{
			path: "/h-:storeId",
			component: _1eba821e,
			name: "h-storeId"
		}
    ],
    
    
    fallback: false
  })
}
